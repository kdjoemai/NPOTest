/*
package com.example.sidratulmuntaha.npotest.model;




import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

*/
/**
 * Created by KaMaL on 23-4-2018.
 *//*


public interface ApiInterface {
    @GET("api/sensordata")
    Call<List<SensorDataObject>> getSensorData();

    @POST("/api/sensordata")
    @FormUrlEncoded
    Call<SensorDataObject> sendSData(@Field("name") String name,
                                     @Field("value") int value
    );
}
*/
