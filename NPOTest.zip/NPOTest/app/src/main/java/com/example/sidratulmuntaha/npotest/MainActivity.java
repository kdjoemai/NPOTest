package com.example.sidratulmuntaha.npotest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.sidratulmuntaha.npotest.View.CustomLayout;
import com.example.sidratulmuntaha.npotest.View.ListAdapter;
import com.example.sidratulmuntaha.npotest.model.DataObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ViewGroup viewGroup;
    ArrayList<DataObject> dataArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataArray = new ArrayList<>();

        dataArray.add(new DataObject("hero", "wil come", "24-4-2019"));
        dataArray.add(new DataObject("ip man", "wil come", "24-4-2019"));
        dataArray.add(new DataObject("ip man2", "wil come", "24-4-2019"));
        dataArray.add(new DataObject("hero academi", "wil come", "24-4-2019"));

        /*ArrayAdapter<DataObject> adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, dataArray);
*/

        ListAdapter adapter = new ListAdapter(this, dataArray);

        viewGroup = findViewById(R.id.singleLayoutContainer);

    }


}
