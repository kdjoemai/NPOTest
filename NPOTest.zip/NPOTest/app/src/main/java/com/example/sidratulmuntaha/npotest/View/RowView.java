package com.example.sidratulmuntaha.npotest.View;

import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RowView extends LinearLayout {

    private TextView mTitle;
    private TextView mResume;


    public RowView(Context context) {
        super(context);

        mTitle = new TextView(context);
        mResume = new TextView(context);

        this.addView(mTitle);
        this.addView(mResume);
    }

    public void setTitle(String text) {
        mTitle.setText(text);
    }

    public void setResume(String text) {
        mResume.setText(text);
    }


}
