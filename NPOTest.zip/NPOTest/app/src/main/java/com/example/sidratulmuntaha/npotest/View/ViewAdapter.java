package com.example.sidratulmuntaha.npotest.View;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sidratulmuntaha.npotest.R;
import com.example.sidratulmuntaha.npotest.model.DataObject;

import java.util.List;

public class ViewAdapter extends RecyclerView.Adapter<ViewAdapter.MyViewHolder> {

    private List<DataObject> mDataObject;
    private Context mContext;

    public ViewAdapter(Context context) {

        this.mContext = context;
//        this.sensorData = sensorData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.singleview, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final DataObject item = mDataObject.get(position);

        holder.title.setText( item.getTitle());
        holder.date.setText(item.getDate());

        holder.mview.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(mContext, "Date : " + item.getDate(), Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    @Override
    public int getItemCount() {
        return mDataObject.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, date;
        public View mview;

        public MyViewHolder(View itemView) {

            super(itemView);

            title = (TextView) itemView.findViewById(R.id.textViewTitle);
            date = (TextView) itemView.findViewById(R.id.textViewDate);
            mview = itemView;
        }
    }
}